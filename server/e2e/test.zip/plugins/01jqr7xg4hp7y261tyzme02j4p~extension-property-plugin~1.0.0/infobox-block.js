reearth.ui.show(`
  <style>

  body,
  h2,
  h3 {
    margin: 0;
    font-family: Arial, sans-serif;
  }

  h2,
  h3 {
    text-align: center;
    margin: 20px;
  }

  #wrapper {
    background: #eee;
    color: #222;
    border-radius: 5px;
    padding: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }

  .flex-center {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 16px;
  }
  </style>

  <div id="wrapper">
    <h2 id="text" style="text-align: center;"></h2>
    <img id="img" style="width:100%;height:auto;">
  </div> 
  
  <script>
    window.addEventListener("message", e => {
      const msg = e.data;
      if (msg.type === "getBlockProperty") {
        document.getElementById("text").textContent = msg.property?.default?.text ?? "";
        document.getElementById("text").style.color = msg.property?.default?.color ?? "";
        document.getElementById("img").src = msg.property?.default?.image ?? "";
      }
    });
  </script>
`);

// Get block property values and send to UI.
// Property schema is defined in reearth.yml.
reearth.ui.postMessage({
  type: "getBlockProperty",
  property: reearth.extension.block?.property
});