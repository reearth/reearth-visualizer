reearth.ui.show(`
  <style>
    html,
    body {
      margin: 0;
      font-size: 14px;
    }
    button {
      margin: 0;
    }
    #wrapper {
      box-sizing: border-box;
      border-radius: 12px;
      padding: 12px;
      background: white;
    }
    h3{
      margin: 0 0 5px;
    }
    h4{
      margin: 5px 0;
    }
    select{
      width: 100%;
      display: block;
    }
  </style>

  <div id="wrapper">
    <h3>Plugin Communication Story Block</h3>
    <div>My ID: <span id="selfId"></span></div>
    <h4>Insetances <button id="getPluginInstances">Get</button><h4>
    <select id="pluginInstanceList"></select>
    <br />
    <span>Send: </span><input id="sendMsg" />
    <button id="sendPluginMessage">Send</button>
    <h4>Receive:</h4>
    <div>Message: <span id="receiveMsg"></span></div>
    <div>Sender: <span id="sender"></span></div>
    <h4>Property:</h4>
    <button id="getPrimaryColor">Get Primary Color</button>
    <div>PrimaryColor: <span id="primaryColor"></span></div>
  </div>

  <script>
    document.getElementById("getPluginInstances").addEventListener("click", (e) => {
      parent.postMessage({ type: "getPluginInstances" }, "*");
    });

    document.getElementById("sendPluginMessage").addEventListener("click", (e) => {
      const selector = document.getElementById("pluginInstanceList");
      const targetId = selector.options[selector.selectedIndex].value;
      const msg = document.getElementById("sendMsg").value;
      parent.postMessage({ type: "sendPluginMessage", msg, targetId }, "*");
    });

    document.getElementById("getPrimaryColor").addEventListener("click", (e) => {
      parent.postMessage({ type: "getPrimaryColor" }, "*");
    });

    addEventListener("message", (e) => {
      if (e.source !== parent) return;
      if(e.data.type === 'getPluginInstances'){
        const instances = e.data.payload;
        if(instances){
          const selector = document.getElementById("pluginInstanceList");
          selector.options.length = 0;
          instances.forEach(instance => {
            selector.options.add(new Option(instance.name + ' (' + instance.extensionId + ' ' + instance.id + ')', instance.id));
          })
        }
      } else if (e.data.type === 'receivePluginMessage') {
        document.getElementById("receiveMsg").innerHTML = e.data.payload.data;
        document.getElementById("sender").innerHTML = e.data.payload.sender;
      } else if (e.data.type === 'getSelfInfo') {
        document.getElementById("selfId").innerHTML = e.data.payload.id;
      } else if (e.data.type === 'getPrimaryColor') {
        document.getElementById("primaryColor").innerHTML = e.data.payload;
      }
    });
  </script>
`);

reearth.on("message", (msg) => {
  if (msg.type === "sendPluginMessage") {
    reearth.plugins.postMessage(msg.targetId, msg.msg);
  }else if(msg.type === 'getPluginInstances'){
    reearth.ui.postMessage({
      type: "getPluginInstances",
      payload: reearth.plugins.instances,
    });
  }else if(msg.type === 'getPrimaryColor'){
    reearth.ui.postMessage({
      type: "getPrimaryColor",
      payload: reearth.block?.property?.appearance?.primary_color?.value,
    });
  }
});

reearth.on("pluginmessage", (msg) => {
  reearth.ui.postMessage({
    type: "receivePluginMessage",
    payload: msg
  });
});

reearth.ui.postMessage({
  type: "getSelfInfo",
  payload: reearth.block
});